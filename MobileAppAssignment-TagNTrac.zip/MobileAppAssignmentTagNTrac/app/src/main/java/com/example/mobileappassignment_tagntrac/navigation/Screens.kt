package com.example.mobileappassignment_tagntrac.navigation

object Screens {
    var signInBaseScreen = "signInBaseScreen"
    var signInScreen = "signInScreen"
    var homeScreen = "homeScreen"
}
